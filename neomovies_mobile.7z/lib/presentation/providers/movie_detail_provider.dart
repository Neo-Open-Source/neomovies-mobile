import 'package:flutter/material.dart';
import 'package:neomovies_mobile/data/models/movie.dart';
import 'package:neomovies_mobile/data/repositories/movie_repository.dart';
import 'package:neomovies_mobile/data/api/api_client.dart';

class MovieDetailProvider extends ChangeNotifier {
  final MovieRepository _movieRepository;
  final ApiClient _apiClient;

  MovieDetailProvider(this._movieRepository, this._apiClient);

  bool _isLoading = false;
  bool get isLoading => _isLoading;

  Movie? _movie;
  Movie? get movie => _movie;

  String? _imdbId;
  String? get imdbId => _imdbId;

  String? _error;
  String? get error => _error;

  Future<void> loadMedia(String mediaId, String mediaType) async {
    try {
      _isLoading = true;
      _error = null;
      _imdbId = null;
      notifyListeners(); // Notify loading start

      // Load movie/tv details
      if (mediaType == 'tv') {
        _movie = await _movieRepository.getTvById(mediaId);
      } else {
        _movie = await _movieRepository.getMovieById(mediaId);
      }

      // Load IMDB ID
      _imdbId = await _apiClient.getImdbId(mediaId, mediaType);
      
      if (_imdbId == null) {
        print('Warning: Could not get IMDB ID for $mediaType $mediaId');
      } else {
        print('Got IMDB ID: $_imdbId for $mediaType $mediaId');
      }

    } catch (e) {
      _error = e.toString();
      print('Error loading media: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // Backward compatibility
  Future<void> loadMovie(String movieId) async {
    await loadMedia(movieId, 'movie');
  }
}
