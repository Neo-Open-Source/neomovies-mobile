import 'package:flutter/material.dart';
import 'package:neomovies_mobile/data/models/user.dart';
import 'package:neomovies_mobile/data/repositories/auth_repository.dart';

enum AuthState { initial, loading, authenticated, unauthenticated, error }

class AuthProvider extends ChangeNotifier {
  AuthProvider({required AuthRepository authRepository})
      : _authRepository = authRepository;

  final AuthRepository _authRepository;

  AuthState _state = AuthState.initial;
  AuthState get state => _state;

  String? _token;
  String? get token => _token;

  // Считаем пользователя аутентифицированным, если состояние AuthState.authenticated
  bool get isAuthenticated => _state == AuthState.authenticated;

  User? _user;
  User? get user => _user;

  String? _error;
  String? get error => _error;

  Future<void> checkAuthStatus() async {
    _state = AuthState.loading;
    notifyListeners();
    try {
      final isLoggedIn = await _authRepository.isLoggedIn();
      if (isLoggedIn) {
        _user = await _authRepository.getCurrentUser();
        _state = AuthState.authenticated;
      } else {
        _state = AuthState.unauthenticated;
      }
    } catch (e) {
      _state = AuthState.unauthenticated;
    }
    notifyListeners();
  }

  Future<void> login(String email, String password) async {
    _state = AuthState.loading;
    _error = null;
    notifyListeners();
    try {
      await _authRepository.login(email, password);
      _user = await _authRepository.getCurrentUser();
      _state = AuthState.authenticated;
    } catch (e) {
      _error = e.toString();
      _state = AuthState.error;
    }
    notifyListeners();
  }

  Future<void> register(String name, String email, String password) async {
    _state = AuthState.loading;
    _error = null;
    notifyListeners();
    try {
      await _authRepository.register(name, email, password);
      // After registration, user needs to verify, so we go to unauthenticated state
      // The UI will navigate to the verify screen
      _state = AuthState.unauthenticated;
    } catch (e) {
      _error = e.toString();
      _state = AuthState.error;
    }
    notifyListeners();
  }

  Future<void> verifyEmail(String email, String code) async {
    _state = AuthState.loading;
    _error = null;
    notifyListeners();
    try {
      await _authRepository.verifyEmail(email, code);
      // After verification, user should log in.
      // For a better UX, we could auto-login them, but for now, we'll just go to the unauthenticated state.
      _state = AuthState.unauthenticated;
    } catch (e) {
      _error = e.toString();
      _state = AuthState.error;
    }
    notifyListeners();
  }

  Future<void> logout() async {
    _state = AuthState.loading;
    notifyListeners();
    await _authRepository.logout();
    _user = null;
    _state = AuthState.unauthenticated;
    notifyListeners();
  }

  Future<void> deleteAccount() async {
    _state = AuthState.loading;
    notifyListeners();
    try {
      await _authRepository.deleteAccount();
      _user = null;
      _state = AuthState.unauthenticated;
    } catch (e) {
      _error = e.toString();
      _state = AuthState.error;
    }
    notifyListeners();
  }
}
