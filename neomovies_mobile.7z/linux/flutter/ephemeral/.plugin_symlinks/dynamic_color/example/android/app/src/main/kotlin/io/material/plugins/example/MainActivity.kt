package io.material.plugins.dynamic_color_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
